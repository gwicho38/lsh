# Path to root repo. Exclude trailing slash
PATH_TO_PACKAGE_REPO = '/Users/lefv/c3/c3wd/rebase/c3generativeAi/genai'

# Listen to file updates within these packages
PACKAGES_TO_SYNC = ['guruSearchUI']

# Exclude trailing slash
APPURL = ''

# Basic auth token for BA:BA
AUTH_TOKEN = 'Basic QkE6QkE='
